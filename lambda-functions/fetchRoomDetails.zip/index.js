const { DynamoDBClient, QueryCommand } = require("@aws-sdk/client-dynamodb");

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
    
    
    console.log("Event: ",event);
    
    const {roomId} = event;
    
    if(!roomId){
        return {
            statusCode: 400,
            body: JSON.stringify({message:
                "Missing roomId from the params."
            })
        }
    }
    
    const params = {
         TableName: 'roomDetails',
            KeyConditionExpression: 'roomId = :roomId',
            ExpressionAttributeValues: {
                ':roomId': { S: roomId }
            }
    }

    try {
        const data = await dynamodbClient.send(new QueryCommand(params));

        console.log("Data: ", data);
        
        if (data.Items && data.Items.length > 0) {
              // Convert DynamoDB JSON to regular JSON
            const item = data.Items[0];
            const response = {
                  tariff: Number(item.tariff.N),
                  capacity: Number(item.capacity.N),
                  amenities: item.amenities.SS,
                  roomType: item.roomType.S,
                  updatedAt: item.updatedAt.S,
                  createdAt: item.createdAt.S,
                  roomId: item.roomId.S,
                  description: item.description.S,
            };
            return {
                statusCode: 200,
                body: JSON.stringify(response),
            };
        } else {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Room details is not found for given roomId!' }),
            };
        }
    } catch (err) {
        console.error("Error fetching room:", err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Could not fetch room" })
        };
    }
};
