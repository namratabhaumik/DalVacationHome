const { DynamoDBClient, QueryCommand } = require('@aws-sdk/client-dynamodb');

const dynamodb = new DynamoDBClient({ region: 'us-east-1' }); 

exports.handler = async (event) => {
    try {
        const {userId} = event;

        console.log("Event : ", event.userId);

        if (!userId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing userId query parameter' }),
            };
        }

        const params = {
            TableName: 'UserSecurityQuestions',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': { S: userId }
            }
        };

        const command = new QueryCommand(params);
        const data = await dynamodb.send(command);

        console.log("Data : ",data)

        if (data.Items && data.Items.length > 0) {
            const item = data.Items[0];
            const response = {
                userId: item.userId.S,
                question: item.question.S,
                answer: item.answer.S,
                timestamp: Number(item.timestamp.N)
            };
            return {
                statusCode: 200,
                body: JSON.stringify(response),
            };
        } else {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Security question not found for the given userId' }),
            };
        }
    } catch (error) {
        console.error('Error fetching from DynamoDB:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' }),
        };
    }
};
