const { DynamoDBClient, QueryCommand } = require("@aws-sdk/client-dynamodb");

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
    
    
    console.log("Event: ",event);
    
    const {roomId} = event;
    
    if(!roomId){
        return {
            statusCode: 400,
            body: JSON.stringify({message:
                "Missing roomId from the params."
            })
        }
    }
    
    const params = {
         TableName: 'roomFeedback',
            KeyConditionExpression: 'roomId = :roomId',
            ExpressionAttributeValues: {
                ':roomId': { S: roomId }
            }
    }

    try {
        const data = await dynamodbClient.send(new QueryCommand(params));

        console.log("Data: ", data);
        console.log("items: ", data.Items)
        
        if (data.Items && data.Items.length > 0) {
              // Convert DynamoDB JSON to regular JSON
            const items = data.Items;
            
            const response = items.map(item => {
                return {
                  feedbackText: item.feedbackText.S,
                  sentiment: item.sentiment.S,
                  timestamp: item.timestamp.N,
                  roomId: item.roomId.S,
                  feedbackId: item.feedbackId.S,
                  userId:item.userId.S
                }
            })
            
            return {
                statusCode: 200,
                body: JSON.stringify(response),
            };
        } else {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Feedback is not found for given roomId!' }),
            };
        }
    } catch (err) {
        console.error("Error fetching feedback:", err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Could not fetch feedback" })
        };
    }
};
