const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');

const dynamodb = new DynamoDBClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    try {
    
        console.log("Event : ",event);

        const { email, question, answer } = event;

        const params = {
            TableName: 'UserSecurityQuestions',
            Item: {
                userId: { S: email }, 
                question: {S: question},
                answer: {S: answer},
                timestamp: { N: Date.now().toString() },
            },
        };
        
        const command = new PutItemCommand(params);
        await dynamodb.send(command);

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Securit question added successfully' }),
        };
    } catch (error) {
        console.error('Error writing to DynamoDB:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' }),
        };
    }
};
