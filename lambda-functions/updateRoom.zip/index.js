const { DynamoDBClient, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
    console.log("Event : ", event);
    const { roomId, roomType, tariff, capacity, amenities, description } = event;

    if (!roomId) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Room ID is required for updating a room" }),
        };
    }

    const params = {
        TableName: "roomDetails",
        Key: {
            roomId: { S: roomId },
        },
        UpdateExpression: "SET roomType = :roomType, tariff = :tariff, #capacity = :capacity, amenities = :amenities, description = :description, updatedAt = :updatedAt",
        ExpressionAttributeNames: {
            "#capacity": "capacity", // Aliasing the reserved keyword 
        },
        ExpressionAttributeValues: {
            ":roomType": { S: roomType },
            ":tariff": { N: tariff.toString() },
            ":capacity": { N: capacity.toString() },
            ":amenities": { SS: amenities },
            ":description": { S: description },
            ":updatedAt": { S: new Date().toISOString() },
        },
        ReturnValues: "UPDATED_NEW",
    };

    try {
        const result = await dynamodbClient.send(new UpdateItemCommand(params));

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Room updated successfully.", updatedAttributes: result.Attributes }),
        };
    } catch (error) {
        console.error('Error while updating a room', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};
