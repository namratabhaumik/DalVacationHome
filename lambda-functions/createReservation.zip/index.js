const { SNSClient, PublishCommand } =  require("@aws-sdk/client-sns");
const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { v4: uuidv4 } = require("uuid");

const snsClient = new SNSClient({ region: 'us-east-1' });
const dynamoDbClient = new DynamoDBClient({ region: 'us-east-1' });

const topicArn = 'arn:aws:sns:us-east-1:774821680662:authentication';

exports.handler = async (event) => {

    console.log("Event: ", event);

    for (const record of event.Records) {

        console.log(record);

        const bookingDetails = JSON.parse(record.body);
        const reservationId = uuidv4();
        let isBookingApproved;

        try {
            const reservationParams = {
                TableName: 'reservationDetails',
                Item: {
                    reservationId: { S: reservationId },
                    roomId: { S: bookingDetails.roomId },
                    userId: { S: bookingDetails.userId },
                    startDate: { S: bookingDetails.startDate },
                    endDate: { S: bookingDetails.endDate },
                    createdAt: { S: new Date().toISOString() },
                    updatedAt: { S: new Date().toISOString() },
                },
            };
            const putCommand = new PutItemCommand(reservationParams);
            await dynamoDbClient.send(putCommand);
            isBookingApproved = true;
            console.log('Reservation saved to DynamoDB successfully');
        } catch (error) {
            console.error('Error saving reservation to DynamoDB', error);
            isBookingApproved = false;
            message = 'Your booking could not be processed due to an internal error.';
        }

        const subject = isBookingApproved ? 'Booking Confirmation' : 'Booking Failure';
        const message = isBookingApproved
            ? `Your booking has been confirmed. Your reservationId is ${reservationId}`
            : 'Your booking could not be processed.';

        const params = {
            Message: message,
            Subject: subject,
            TopicArn: topicArn,
            MessageAttributes: {
                'email': {
                    DataType: 'String',
                    StringValue: bookingDetails.userId
                }
            }
        };

        try {
            const command = new PublishCommand(params);
            await snsClient.send(command);
            console.log('Notification sent successfully');
        } catch (error) {
            console.error('Error sending notification', error);
        }
    }
};
