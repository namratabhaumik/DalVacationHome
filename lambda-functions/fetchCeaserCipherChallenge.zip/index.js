const { DynamoDBClient, GetItemCommand } = require('@aws-sdk/client-dynamodb');
const { unmarshall } = require('@aws-sdk/util-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    
    const {userId} = event;
    
    
    const params = {
        TableName: "ceaserCipher",
        Key: {
            userId: { S: userId }
        }
    };

    try {
        const command = new GetItemCommand(params);
        const data = await client.send(command);
        
        console.log("Data: ",data);

        if (!data.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Clue not found' })
            };
        }

        const { clue, answer } = unmarshall(data.Item);
        
        console.log("clue: ",clue)

        return {
            statusCode: 200,
            body: JSON.stringify({
                clue: clue,
                answer: answer
            })
        };
    } catch (error) {
        console.error('Error retrieving clue:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to retrieve clue' })
        };
    }
};
