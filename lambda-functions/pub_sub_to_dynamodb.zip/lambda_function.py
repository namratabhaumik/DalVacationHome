import json
import boto3

# Initialize DynamoDB resource and table
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CustomerConcerns')

def lambda_handler(event, context):
    """
    AWS Lambda function to process messages and store them in a DynamoDB table.
    """
    try:
        # Parse the incoming event data
        event_body = event.get('body', None)

        if not event_body:
            return {
                'statusCode': 400,
                'body': json.dumps('Error: Missing request body')
            }

        # Parse the JSON data from the event body
        data = json.loads(event_body)

        message_data = data.get('body', None)

        if not message_data:
            raise ValueError('Invalid message format: body attribute is missing')

        # Ensure the customer_email is present in the message_data
        if 'customer_email' not in message_data:
            return {
                'statusCode': 400,
                'body': json.dumps('Error: customer_email missing from data')
            }
        else:
            customer_email = message_data.get('customer_email','')
            customer_concern = message_data.get('customer_concern','')
            assigned_agent = message_data.get('assigned_agent','')

        try:
            # Save data to DynamoDB with customer_email as the partition key
            table.put_item(
                Item={
                    'EmailAddress': customer_email,
                    'CustomerConcern': customer_concern,
                    'AgentEmail': assigned_agent
                }
            )
            print(f"Data saved to DynamoDB: {message_data}")

        except Exception as e:
            print(f"Error saving to DynamoDB: {e}")
            return {
                'statusCode': 500,
                'body': json.dumps(f'Error saving to DynamoDB: {str(e)}')
            }

        return {
            'statusCode': 200,
            'body': json.dumps('Message processed and stored in DynamoDB')
        }

    except json.JSONDecodeError as json_error:
        print(f"Error decoding JSON: {json_error}")
        return {
            'statusCode': 400,
            'body': json.dumps(f'Error decoding JSON: {str(json_error)}')
        }

    except ValueError as val_error:
        print(f"Value error: {val_error}")
        return {
            'statusCode': 400,
            'body': json.dumps(f'Value error: {str(val_error)}')
        }

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
