const { DynamoDBClient, ScanCommand } = require("@aws-sdk/client-dynamodb");

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
    const params = {
        TableName: "roomDetails"
    };

    try {
        const data = await dynamodbClient.send(new ScanCommand(params));

        console.log("Data: ", data);
        console.log(JSON.stringify(data.Items));
        return {
            statusCode: 200,
            body: JSON.stringify(data.Items)
        };
    } catch (err) {
        console.error("Error fetching rooms:", err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Could not fetch rooms" })
        };
    }
};
