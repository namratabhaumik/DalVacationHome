const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { v4: uuidv4 } = require("uuid");

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {


    console.log("Event : ", event);
    const { roomType,tariff,capacity,amenities,description, } = event;
    const roomId = uuidv4();

     const params = {
        TableName: "roomDetails",
        Item: {
            roomId: { S: roomId },
            roomType: { S: roomType },
            tariff: { N: tariff.toString() },
            capacity: { N: capacity.toString() },
            amenities: { SS: amenities },
            description: { S: description },
            createdAt: { S: new Date().toISOString() },
            updatedAt: { S: new Date().toISOString() },
        },
    };

    try {

        await dynamodbClient.send(new PutItemCommand(params));

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Room added successfully." }),
        };

    } catch (error) {
        console.error('Error while adding a room', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};

