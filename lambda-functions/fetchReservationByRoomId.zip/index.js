const { DynamoDBClient, QueryCommand } = require("@aws-sdk/client-dynamodb");
const {unmarshall} = require("@aws-sdk/util-dynamodb")

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
    
    console.log("Event: ", event);
    
    const { roomId } = event;

    if (!roomId) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Missing required parameter: roomId" }),
        };
    }

    const params = {
        TableName: "reservationDetails",
        IndexName: "roomIdIndex",
        KeyConditionExpression: 'roomId = :roomId',
            ExpressionAttributeValues: {
                ':roomId': { S: roomId }
            }
    };

    try {
    
        const data = await dynamodbClient.send(new QueryCommand(params));
        console.log("Data: ",data);


        if (!data.Items) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: "Reservation not found" }),
            };
        }
        
        const reservations = data.Items.map(item => unmarshall(item));

        return {
            statusCode: 200,
            body: JSON.stringify({reservations})
        };
    } catch (error) {
        console.error('Error while retrieving the reservations:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};
