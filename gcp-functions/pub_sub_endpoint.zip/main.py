import base64
import json
import google.auth
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from flask import jsonify, request

# Configuration
PROJECT_ID = 'nimble-analyst-402215'
TOPIC_ID = 'customer-concerns'

def publish_message(request):
    """
    Publishes a message to a Google Cloud Pub/Sub topic.
    """
    try:
        # Parse the request JSON
        request_json = request.get_json()

        if not request_json or 'message' not in request_json:
            return jsonify({'error': 'Invalid request'}), 400

        message = request_json['message']

        # Ensure the message is a string
        if isinstance(message, dict):
            message_str = json.dumps(message)
        else:
            message_str = str(message)
        
        # Get Google Cloud credentials and create the Pub/Sub service client
        credentials, project = google.auth.default()
        service = build('pubsub', 'v1', credentials=credentials)
        
        topic_path = f'projects/{PROJECT_ID}/topics/{TOPIC_ID}'
        
        # Create the Pub/Sub message body
        body = {
            "messages": [
                {
                    "data": base64.b64encode(message_str.encode('utf-8')).decode('utf-8')
                }
            ]
        }
        
        # Publish the message to the Pub/Sub topic
        request = service.projects().topics().publish(topic=topic_path, body=body)
        response = request.execute()
        print(f'Published message ID: {response["messageIds"][0]}')

        return jsonify({'message': 'Message published successfully'}), 200

    except google.auth.exceptions.GoogleAuthError as auth_error:
        print(f'Authentication error: {auth_error}')
        return jsonify({'error': 'Authentication error'}), 500

    except Exception as e:
        print(f'An error occurred: {e}')
        return jsonify({'error': 'An internal error occurred'}), 500
